public final class Boss extends Employee
{
    private double weeklySalary;

    public Boss(String name, double weeklySalary)
    {
        super(name);
        this.weeklySalary = weeklySalary;
    }

    public double earnings()
    {
        return weeklySalary;
    }

    public String getEmployeeType()
    {
        return "Boss";
    }
}
