public final class HourlyWorker extends Employee
{
    public static final double HOURLY_RATE = 500.00;
    private double hoursWorked;

    public HourlyWorker(String name, double hoursWorked)
    {
        super(name);
        this.hoursWorked = hoursWorked;
    }

    public double earnings()
    {
        if (hoursWorked <= 40)
        {
            return hoursWorked * HOURLY_RATE;
        }

        double regularPay = 40 * HOURLY_RATE;
        double overtimeHours = hoursWorked - 40;
        double overtimePay = overtimeHours * HOURLY_RATE * 1.5;
        return regularPay + overtimePay;
    }

    public String getEmployeeType()
    {
        return "Hourly Worker";
    }
}
