public final class CommissionWorker extends Employee
{
    private double weeklySalary;

    public CommissionWorker(String name, double weeklySalary)
    {
        super(name);
        this.weeklySalary = weeklySalary;
    }

    public double earnings()
    {
        return weeklySalary;
    }

    public String getEmployeeType()
    {
        return "Commission Worker";
    }
}
