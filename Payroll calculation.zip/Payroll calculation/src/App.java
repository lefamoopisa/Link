public class App
{
    public static void main(String[] args)
    {
        // Create the employees
        Employee boss = new Boss("Lefa", 3000.00);
        Employee commissionWorker = new CommissionWorker("Mpho", 1500.00);
        Employee pieceWorker = new PieceWorker("Thomas", 120, 25.00);
        Employee hourlyWorker = new HourlyWorker("Moopisa", 45);

        // Print what each employee earned
        System.out.println("Payroll Results:");
        printEarnings(boss);
        printEarnings(commissionWorker);
        printEarnings(pieceWorker);
        printEarnings(hourlyWorker);
    }

    public static void printEarnings(Employee employee)
    {
        System.out.println(employee.getEmployeeType() + ": " + employee.getName() + " earned M" + employee.earnings());
    }
}