public final class PieceWorker extends Employee
{
    private int numberOfProducts;
    private double payPerProduct;

    public PieceWorker(String name, int numberOfProducts, double payPerProduct)
    {
        super(name);
        this.numberOfProducts = numberOfProducts;
        this.payPerProduct = payPerProduct;
    }

    public double earnings()
    {
        return numberOfProducts * payPerProduct;
    }

    public String getEmployeeType()
    {
        return "Piece Worker";
    }
}
