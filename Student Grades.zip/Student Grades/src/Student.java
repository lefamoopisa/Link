public class Student
{
    public String checkGrade(int marks)
    {
        if (marks >= 70)
        {
            return "Distinction";
        }
        else if (marks >= 50)
        {
            return "Pass";
        }
        else
        {
            return "Fail";
        }
    }
}
