public class App
{
    public static void main(String[] args)
    {
        Student student = new Student();

        System.out.println(student.checkGrade(75));
        System.out.println(student.checkGrade(45));
    }
}
